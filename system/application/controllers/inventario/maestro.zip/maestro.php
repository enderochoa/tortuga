<?php
class Maestro extends Controller {
	
	function Maestro(){
		parent::Controller(); 
		$this->load->library("rapyd");
	}
	
	##### index #####
	function index(){
		//$this->datasis->modulo_id(309,1);
		redirect("inventario/maestro/filteredgrid");
	}
	
	##### DataFilter + DataGrid #####
	function filteredgrid(){
		$this->rapyd->load("datafilter2","datagrid");
		//$this->rapyd->uri->keep_persistence();
		
		$mSPRV=array(
			'tabla'   =>'sprv',
			'columnas'=>array(
				'proveed' =>'C&oacute;odigo',
				'nombre'=>'Nombre',
				'contacto'=>'Contacto'),
			'filtro'  =>array('proveed'=>'C&oacute;digo','nombre'=>'Nombre'),
			'retornar'=>array('proveed'=>'proveed'),
			'titulo'  =>'Buscar Proveedor');
		
		$bSPRV=$this->datasis->modbus($mSPRV);

		rapydlib("prototype");
		$ajax_onchange = '
			  function get_linea(){
			    var url = "'.site_url('reportes/sinvlineas').'";
			    var pars = "dpto="+$F("depto");
			    var myAjax = new Ajax.Updater("td_linea", url, { method: "post", parameters: pars });
			    get_grupo();
			  }
			  
			  function get_grupo(){
			    var url = "'.site_url('reportes/sinvgrupos').'";
			    var pars = "dpto="+$F("depto")+"&linea="+$F("linea");
			    var myAjax = new Ajax.Updater("td_grupo", url, { method: "post", parameters: pars });
			  }';
			  
		
		//filter
		$filter = new DataFilter2("Filtro por Producto", 'sinv');
		$filter->script($ajax_onchange);
		
		$filter->codigo = new inputField("C&oacute;digo", "codigo");
		
		$filter->descrip = new inputField("Descripci&oacute;n", "descrip");
		$filter->descrip->db_name='CONCAT_WS(" ",descrip,descrip2)';
		
		$filter->tipo = new dropdownField("Tipo", "tipo");
		$filter->tipo->option("","Todos");
		$filter->tipo->option("Articulo","Art&iacute;culo");
		$filter->tipo->option("Servicio","Servicio");
		$filter->tipo->option("Descartar","Descartar");
		$filter->tipo->option("Consumo","Consumo");
		$filter->tipo->option("Fraccion","Fracci&oacute;n");
		
		$filter->clave = new inputField("Clave", "clave");

		$filter->activo = new dropdownField("Activo", "activo");
		$filter->activo->option("","");
		$filter->activo->option("S","Si");
		$filter->activo->option("N","No");
		
		$filter->proveed = new inputField("Proveedor", "proveed");
		$filter->proveed->append($bSPRV);
		$filter->proveed->clause ="in";
		$filter->proveed->db_name='( s.prov1, s.prov2, s.prov3 )';
		
		$filter->depto = new dropdownField("Departamento", "depto");  
		$filter->depto->option("","");  
		$filter->depto->options("SELECT depto, descrip FROM dpto ORDER BY depto");
		$filter->depto->onchange = "get_linea();";
		$filter->depto->group = "Producto";
		
		$filter->linea = new dropdownField("L&iacute;nea", "linea");  
		$filter->linea->option("","Selecione un Departamento");
		$filter->linea->onchange = "get_grupo();";
		$filter->linea->group    = "Producto";
		
		$filter->grupo = new dropdownField("Grupo", "grupo");  
		$filter->grupo->option("","Seleccione una L&iacute;nea");
		$filter->grupo->group = "Producto";
		$filter->grupo->db_name='a.grupo';
		
		$filter->marca = new dropdownField("Marca", "marca");
		$filter->marca->option("","");  
		$filter->marca->options("SELECT TRIM(marca) AS clave, TRIM(marca) AS valor FROM marc ORDER BY marca"); 
    
		$filter->buttons("reset","search");
		$filter->build();
		
		$uri = "inventario/maestro/dataedit/modify/<#codigo#>";
		
		$grid = new DataGrid("Lista de Art&iacute;culos");
		$grid->order_by("codigo","asc");
		$grid->per_page = 15;
		
		$grid->column_detail("c&oacute;digo","codigo", $uri);
		$grid->column("Descripci&oacute;n","descrip");
		$grid->column("Precio 1","precio1");
		$grid->column("Precio 2","precio2");
		$grid->column("Precio 3","precio3");
		$grid->column("Precio 4","precio4");

										
		$grid->add("inventario/departamentos/dataedit/create");
		$grid->build();
		//grid
		
		$data["crud"] = $filter->output . $grid->output;
		$data["titulo"] = 'Lista de Departamentos';

		$content["content"]   = $this->load->view('rapyd/crud', $data, true);
		$content["rapyd_head"] = $this->rapyd->get_head();
		$content["code"] = '';
		$content["lista"] = "
			<h3>Editar o Agregar</h3>
			<div>Con esta pantalla se puede editar o agregar datos a los Departamentos del M&oacute;dulo de Inventario</div>
			<div class='line'></div>
			<a href='#' onclick='window.close()'>Cerrar</a>
			<div class='line'></div>\n<br><br><br>\n";
		$this->load->view('rapyd/tmpsolo', $content);
	}

	##### dataedit ##### 
	function dataedit(){
		$this->rapyd->load("fields");
		$this->rapyd->load("dataobject");
		rapydlib("prototype");
		$status = $this->uri->segment(4);
		$consul = $this->uri->segment(5);
		
		//echo '<pre>';
		//print_r($_POST);
		//echo '</pre>';
		
		$do = new DataObject("sinv");
		$do->rel_one_to_many("alma","itsinv","codigo");		
		$do->load($consul);
		$getDepto=$do->get('depto');
		$getLinea=$do->get('linea');
		
		$eventosm=array('onkeydown'=>'calcula("m");',  'onkeypress'=>'calcula("m");', 'onkeyup'=>'calcula("m");');
		$eventosb=array('onkeydown'=>'calcula("b");',  'onkeypress'=>'calcula("b");', 'onkeyup'=>'calcula("b");');
		$eventosp=array('onkeydown'=>'calcula("p");',  'onkeypress'=>'calcula("p");', 'onkeyup'=>'calcula("p");');
		
		$ajax_onchange = '
	  function get_linea(){
	    var url = "'.site_url('reportes/sinvlineas').'";
	    var pars = "dpto="+$F("depto");
	    var myAjax = new Ajax.Updater("td_linea", url, { method: "post", parameters: pars });
	    get_grupo();
	  }
	  
	  function get_grupo(){
	    var url = "'.site_url('reportes/sinvgrupos').'";
	    var pars = "dpto="+$F("depto")+"&linea="+$F("linea");
	    var myAjax = new Ajax.Updater("td_grupo", url, { method: "post", parameters: pars });
	  }
	  ';
		$script="<script type='text/javascript'> 
		function roundNumber(num, dec) {
			var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
			return result;
		}
		function calcula(target){
			var i,magen,base,precio,costo,formcal,ultimo,pond,iva;
			
			formcal=document.getElementById('formcal').value;
			iva    =parseFloat(document.getElementById('iva').value);
			ultimo =parseFloat(document.getElementById('ultimo').value);
			pond   =parseFloat(document.getElementById('pond').value);
			
			if(formcal=='P')
				costo=pond;
			else if(formcal=='U')
				costo=ultimo;
			else{
				if (ultimo>pond)
					costo=ultimo;
				else
					costo=pond;
			}
			//alert('pase');
			for(i=1;i<5;i++){
				margen=document.getElementById('margen'+i).value;
				base  =document.getElementById('base'+i).value;
				precio=document.getElementById('precio'+i).value;
				
				switch(target){
				case 'm':
					base  =costo*100/(100-margen);
					precio=base*(1+(iva/100));
				break;
				case 'b':
					precio=base*(1+(iva/100));
					margen=100-(costo*100/base);
				break;
				case 'p':
					base  = precio*100/(100+iva);
					margen=100-costo*100/base;
				break;
				}
				document.getElementById('margen'+i).value=roundNumber(margen,2);
				document.getElementById('base'+i).value  =roundNumber(base,2);
				document.getElementById('precio'+i).value=roundNumber(precio,2); 
			}
		}
		$ajax_onchange
		</script>";
		
		$codigo = new inputField("C&oacute;digo", "codigo");
		$codigo->data   = $do;
		$codigo->size   = 15;
		$codigo->status = $status;
		$codigo->rule   = "required|min_length[5]";  
		$codigo->build();
	
		$tipo = new dropdownField("Tipo", "tipo");
		$tipo->style="width:90px;";
		$tipo->data   = $do;
		$tipo->option("","Todos");
		$tipo->status = $status;
		$tipo->option("Articulo","Art&iacute;culo");
		$tipo->option("Servicio","Servicio");
		$tipo->option("Descartar","Descartar");
		$tipo->option("Consumo","Consumo");
		$tipo->option("Fraccion","Fracci&oacute;n");
		$tipo->autoUpdate();
		$tipo->build();
		
		$activo = new dropdownField("Activo", "activo");
		$activo->style="width:50px;";
		$activo->data   = $do;
		$activo->status = $status;
		$activo->option("S","Si");
		$activo->option("N","No");
		$activo->autoUpdate();
		$activo->build();
		
		$decimal = new dropdownField("Decimal", "tdecimal");
		$decimal->style="width:50px;";
		$decimal->data   = $do;
		$decimal->status = $status;
		$decimal->option("S","Si");
		$decimal->option("N","No");
		$decimal->autoUpdate();
		$decimal->build(); 
		
		$serial = new dropdownField("Serial", "serial");
		$serial->style="width:50px;";
		$serial->data   = $do;
		$serial->status = $status;
		$serial->option("S","Si");
		$serial->option("N","No");
		$serial->autoUpdate();
		$serial->build();
		
		$alterno = new inputField("Alterno", "alterno");
		$alterno->data   = $do;
		//$alterno->action = "update";
		$alterno->autoUpdate();
		$alterno->size   = 15;
		$alterno->status = $status;
		$alterno->build();
		
		$uxcaja = new inputField("Uxcajas", "fracci");
		$uxcaja->style="text-align:right";
		$uxcaja->data   = $do;
		$uxcaja->size   =5;
		$uxcaja->status = $status;
		$uxcaja->autoUpdate();
		$uxcaja->build();
		
		$comision = new inputField("Comision", "comision");
		$comision->style="text-align:right";
		$comision->data   = $do;
		$comision->size   = 5;
		$comision->status = $status;
		$comision->rule   = "required|min_length[5]";
		$comision->autoUpdate();
		$comision->build();
		
		$unidad = new dropdownField("Unidad", "unidad");
		$unidad->style="width:90px;";
		$unidad->data   = $do;
		$unidad->status = $status;
		$unidad->option("","");
		$unidad->options('SELECT unidades clave, unidades from unidad ORDER BY unidades');
		$unidad->autoUpdate();
		$unidad->build();
		
		$barras = new inputField("Barras", "barras");
		$barras->data   = $do;
		$barras->size   = 15;
		$barras->status = $status;
		$barras->rule   = "required|min_length[5]";
		$barras->autoUpdate();
		$barras->build();
		
		$descrip = new inputField("Descrici&oacute;n", "descrip");
		$descrip->data   = $do;
		$descrip->size   = 45;
		$descrip->status = $status;
		$descrip->rule   = "required|min_length[5]";
		$descrip->autoUpdate();
		$descrip->build();
		
		$descrip2 = new inputField("", "descrip2");
		$descrip2->data   = $do;
		$descrip2->size   = 45;
		$descrip2->status = $status;
		$descrip2->rule   = "required|min_length[5]";
		$descrip2->autoUpdate();
		$descrip2->build();
		
		$peso = new inputField("Pesos Kg", "peso");
		$peso->style="text-align:right";
		$peso->data   = $do;
		$peso->size   = 10;
		$peso->status = $status;
		$peso->rule   = "required|min_length[5]";
		$peso->autoUpdate();
		$peso->build();
		
		$marca = new dropdownField("Marca", "marca");
		$marca->data   = $do;
		$marca->option("","");
		$marca->options("SELECT marca as codigo, marca FROM marc ORDER BY marca");
		$marca->status = $status;
		$marca->style  = "width:100px;";
		$marca->autoUpdate();
		$marca->build();
		
		$modelo = new inputField("Modelo", "modelo");
		$modelo->data   = $do;
		$modelo->size   = 10;
		$modelo->status = $status;
		$modelo->rule   = "required|min_length[5]";
		$modelo->autoUpdate();
		$modelo->build();
		
		$caja = new inputField("Caja", "enlace");
		$caja->data   = $do;
		$caja->size   = 15;
		$caja->status = $status;
		$caja->rule   = "required|min_length[5]";
		$caja->autoUpdate();
		$caja->build();
		
		$clave = new inputField("Clave", "clave");
		$clave->data   = $do;
		$clave->size   = 10;
		$clave->status = $status;
		$clave->rule   = "required|min_length[5]";
		$clave->autoUpdate();
		$clave->build();
		
		$clase = new dropdownField("Clase", "clase");
		$clase->style="width:40px;";
		$clase->data   = $do;
		$clase->status = $status;
		$clase->option("A","A");
		$clase->option("B","B");
		$clase->option("C","C");
		$clase->option("D","D");
		$clase->autoUpdate();
		$clase->build();


		$promedio=new inputField("Promedio", "pond");
		$promedio->onchange = "calcula('m');";
		$promedio->style="text-align:right";
		$promedio->data   = $do;
		$promedio->size   = 15;
		$promedio->status = $status;
		$promedio->autoUpdate();
		$promedio->build();
		
		$ultimo =new inputField("Ultimo", "ultimo");
		$ultimo->onchange = "calcula('m');";
		$ultimo->style="text-align:right";
		$ultimo->data   = $do;
		$ultimo->size   = 15;
		$ultimo->status = $status;
		$ultimo->autoUpdate();
		$ultimo->build();
		
		$us=	new inputField("US$", "dolar");
		$us->style="text-align:right";
		$us->data   = $do;
		$us->size   = 15;
		$us->status = $status;
		$us->autoUpdate();
		$us->build();
		
		$iva =new inputField("I.V.A.", "iva");
		$iva->onchange = "calcula('m');";
		$iva->style="text-align:right";
		$iva->data   = $do;
		$iva->size   = 6;
		$iva->status = $status;
		$iva->autoUpdate();
		$iva->build();
		
		$venta =new dateField("Venta", "fechav",'d/m/Y');
		$venta->data   = $do;
		$venta->size   = 10;
		$venta->status = $status;
		$venta->autoUpdate();
		$venta->build();
		
		$margen1= new inputField("margen 1", "margen1");
		$margen1->onchange = "calcula('m');";
		$margen1->style="text-align:right";
		$margen1->data   = $do;
		$margen1->size   = 6;
		$margen1->status = $status;
		$margen1->autoUpdate();
		$margen1->build();
     
		$margen2= new inputField("margen 2", "margen2");
		$margen2->onchange = "calcula('m');";
		$margen2->style="text-align:right";
		$margen2->data   = $do;
		$margen2->size   = 6;
		$margen2->status = $status;
		$margen2->autoUpdate();
		$margen2->build();
   
		$margen3= new inputField("margen 3", "margen3");
		$margen3->onchange = "calcula('m');";
		$margen3->style="text-align:right";
		$margen3->data   = $do;
		$margen3->size   = 6;
		$margen3->status = $status;
		$margen3->autoUpdate();
		$margen3->build();

		$margen4= new inputField("margen 4", "margen4");
		$margen4->onchange = "calcula('m');";
		$margen4->style="text-align:right";
		$margen4->data   = $do;
		$margen4->size   = 6;
		$margen4->status = $status;
		$margen4->autoUpdate();
		$margen4->build();
		
		$base1= new inputField("Base 1", "base1");
		$base1->onchange = "calcula('b');";
		$base1->style="text-align:right";
		$base1->data   = $do;
		$base1->size   = 15;
		$base1->status = $status;
		$base1->autoUpdate();
		$base1->build();

		$base2= new inputField("Base 2", "base2");
		$base2->onchange = "calcula('b');";
		$base2->style="text-align:right";
		$base2->data   = $do;
		$base2->size   = 15;
		$base2->status = $status;
		$base2->autoUpdate();
		$base2->build();
             
		$base3= new inputField("Base 3", "base3",$eventosb);
		$base3->onchange = "calcula('b');";
		$base3->style="text-align:right";
		$base3->data   = $do;
		$base3->size   = 15;
		$base3->status = $status;
		$base3->autoUpdate();
		$base3->build();

		$base4= new inputField("Base 4", "base4");
		$base4->onchange = "calcula('b');";
		$base4->style="text-align:right";
		$base4->data   = $do;
		$base4->size   = 15;
		$base4->status = $status;
		$base4->autoUpdate();
		$base4->build();
		
		$precio1= new inputField("Precio 1", "precio1");
		$precio1->onchange = "calcula('p');";
		$precio1->style="text-align:right";
		$precio1->data   = $do;
		$precio1->size   = 15;
		$precio1->status = $status;
		$precio1->autoUpdate();
		$precio1->build();
		
		$precio2= new inputField("Precio 2", "precio2");
		$precio2->onchange = "calcula('p');";
		$precio2->style="text-align:right";
		$precio2->data   = $do;
		$precio2->size   = 15;
		$precio2->status = $status;
		$precio2->autoUpdate();
		$precio2->build();
		                      
		$precio3= new inputField("Precio 3", "precio3");
		$precio3->onchange = "calcula('p');";
		$precio3->style="text-align:right";
		$precio3->data   = $do;
		$precio3->size   = 15;
		$precio3->status = $status;
		$precio3->autoUpdate();
		$precio3->build();
		
		$precio4= new inputField("Precio 4", "precio4");
		$precio4->onchange = "calcula('p');";
		$precio4->style="text-align:right";
		$precio4->data   = $do;
		$precio4->size   = 15;
		$precio4->status = $status;
		$precio4->autoUpdate();
		$precio4->build();
		
		$minima =new inputField("Minima 4", "exmin");
		$minima->style="text-align:right";
		$minima->data   = $do;
		$minima->size   = 8;
		$minima->status = $status;
		$minima->autoUpdate();
		$minima->build();
		
		$maxima =new inputField("Maxima 4", "exmax");
		$maxima->style="text-align:right";
		$maxima->data   = $do;
		$maxima->size   = 8;
		$maxima->status = $status;
		$maxima->autoUpdate();
		$maxima->build();
		
		$ordena =new inputField("Precio 4", "exord");
		$ordena->style="text-align:right";
		$ordena->data   = $do;
		$ordena->size   = 8;
		$ordena->status = $status;
		$ordena->autoUpdate();
		$ordena->build();
		
		$pdesp  =new inputField("Precio 4", "exdes");
		$pdesp->style="text-align:right";
		$pdesp->data   = $do;
		$pdesp->size   = 8;
		$pdesp->status = $status;
		$pdesp->autoUpdate();
		$pdesp->build();
		
		$actual =new inputField("Precio 4", "existen");
		$actual->style="text-align:right";
		$actual->data   = $do;
		$actual->size   = 8;
		$actual->status = $status;
		$actual->autoUpdate();
		$actual->build();
		
		$submit = new submitField("Ok", "submitbtn");
		$submit->status = $status;
		$submit->build();   
		
		$prov1  =new inputField("Proveedor 1", "prov1");
		$prov1->data   = $do;
		$prov1->size   = 6;
		$prov1->status = $status;
		$prov1->autoUpdate();
		$prov1->build();
		
		$pfecha1=new dateField("Fecha" , "pfecha1",'d/m/Y');
		$pfecha1->data   = $do;
		$pfecha1->size   = 10;
		$pfecha1->status = $status;
		$pfecha1->autoUpdate();
		$pfecha1->build();
		
		$prepro1=new inputField("Precio 1"   , "prepro1");
		$prepro1->style="text-align:right";
		$prepro1->data   = $do;
		$prepro1->size   = 15;
		$prepro1->status = $status;
		$prepro1->autoUpdate();
		$prepro1->build();
		
		$prov2  =new inputField("Proveedor 2", "prov2");
		$prov2->data   = $do;
		$prov2->size   = 6;
		$prov2->status = $status;
		$prov2->autoUpdate();
		$prov2->build();
		
		$pfecha2=new dateField("Fecha" , "pfecha2",'d/m/Y');
		$pfecha2->data   = $do;
		$pfecha2->size   = 10;
		$pfecha2->status = $status;
		$pfecha2->autoUpdate();
		$pfecha2->build();
		
		$prepro2=new inputField("Precio 2"   , "prepro2");
		$prepro2->style="text-align:right";
		$prepro2->data   = $do;
		$prepro2->size   = 15;
		$prepro2->status = $status;
		$prepro2->autoUpdate();
		$prepro2->build();
		
		$prov3  =new inputField("Proveedor 3", "prov3");
		$prov3->data   = $do;
		$prov3->size   = 6;
		$prov3->status = $status;
		$prov3->autoUpdate();
		$prov3->build();
		
		$pfecha3=new dateField("Fecha", "pfecha3",'d/m/Y');
		$pfecha3->data   = $do;
		$pfecha3->size   = 10;
		$pfecha3->status = $status;
		$pfecha3->autoUpdate();
		$pfecha3->build();
		
		$prepro3=new inputField("Precio 3"   , "prepro3");
		$prepro3->style="text-align:right";
		$prepro3->data   = $do;
		$prepro3->size   = 15;
		$prepro3->status = $status;
		$prepro3->autoUpdate();
		$prepro3->build();
		
		$formcal=new dropdownField("Calcular", "formcal");
		$formcal->style="width:90px;";
		$formcal->data   = $do;
		$formcal->status = $status;
		$formcal->option("P","Promedio");
		$formcal->onchange = "calcula('m');";
		$formcal->option("U","Ultimo");
		$formcal->option("M","Mayor");
		$formcal->autoUpdate();
		$formcal->build();
		
		$redecen=new dropdownField("Calcular", "redecen");
		$redecen->style="width:90px;";
		$redecen->data   = $do;
		$redecen->status = $status;
		$redecen->option("N","No");
		$redecen->option("F","Fraccion");
		$redecen->option("D","Decena");
		$redecen->option("C","Centena");
		$redecen->autoUpdate();
		$redecen->build();
		
		$garantia  =new inputField("Dias de Garantia", "garantia");
		$garantia->style="text-align:right";
		$garantia->data   = $do;
		$garantia->size   = 4;
		$garantia->status = $status;
		$garantia->autoUpdate();
		$garantia->build();
		
		$dpto = new dropdownField("Departamento", "depto");
		$dpto->data   = $do;
		$dpto->option("","");  
		$dpto->options("SELECT depto, descrip FROM dpto ORDER BY depto");
		$dpto->onchange = "get_linea();";
		$dpto->status = $status;
		$dpto->autoUpdate();
		$dpto->build();
		
		$linea = new dropdownField("Departamento", "linea"); 
		$linea->data = $do;  
		$linea->option("","Seleccione un departamento");
		$linea->options("SELECT linea, descrip FROM line WHERE depto='$getDepto'");
		$linea->onchange = "get_grupo();";
		$linea->status = $status;
		$linea->autoUpdate();
		$linea->build();
		
		$grupo = new dropdownField("Grupo", "grupo");
		$grupo->data   = $do;
		$grupo->option("","Seleccione una L&iacute;nea");
		$grupo->options("SELECT grupo, nom_grup FROM grup WHERE depto='$getDepto' AND linea='$getLinea'");
		$grupo->status = $status;
		$grupo->autoUpdate();
		$grupo->build();
		
		$save = new submitField("Guardar", "save");
		$save ->status = $status;
		$save ->build();
		
		if(isset($_POST['save'])){
			$do->save();
		}
		
		$data["codigo"]   = $codigo->output;
		$data["tipo"]     = $tipo->output;
		$data["grupo"]    = $grupo->output;
		$data["activo"]   = $activo->output;
		$data["alterno"]  = $alterno->output;
		$data["unidad"]   = $unidad->output;
		$data["comision"] = $comision->output;
		$data["serial"]   = $serial->output;
		$data["caja"]     = $caja->output;
		$data["clave"]    = $clave->output;
		$data["uxcajas"]  = $uxcaja->output;
		$data["decimal"]  = $decimal->output;
		$data["barras"]   = $barras->output;
		$data["descrip"]  = $descrip->output;
		$data["peso"]     = $peso->output;
		$data["descrip2"] = $descrip2->output;
		$data["marca"]    = $marca->output;
		$data["modelo"]   = $modelo->output;
		$data["clase"]    = $clase->output;
		
		$data["promedio"] = $promedio->output;
		$data["ultimo"]   = $ultimo->output;
		$data["us"]       = $us->output;
		$data["iva"]      = $iva->output;
		$data["venta"]    = $venta->output;
		$data["margen1"]  = $margen1->output;
		$data["margen2"]  = $margen2->output;
		$data["margen3"]  = $margen3->output;
		$data["margen4"]  = $margen4->output;
		$data["base1"]    = $base1->output;
		$data["base2"]    = $base2->output;
		$data["base3"]    = $base3->output;
		$data["base4"]    = $base4->output;
		$data["precio1"]  = $precio1->output;
		$data["precio2"]  = $precio2->output;
		$data["precio3"]  = $precio3->output;
		$data["precio4"]  = $precio4->output;
		$data["minima"]   = $minima->output;
		$data["maxima"]   = $maxima->output;
		$data["ordena"]   = $ordena->output;
		$data["pdesp"]    = $pdesp->output;
		$data["actual"]   = $actual->output;
		
		$data["prov1"]    = $prov1->output;
		$data["pfecha1"]  = $pfecha1->output;
		$data["prepro1"]  = $prepro1->output;
		$data["prov2"]    = $prov2->output;
		$data["pfecha2"]  = $pfecha2->output;
		$data["prepro2"]  = $prepro2->output;
		$data["prov3"]    = $prov3->output;
		$data["pfecha3"]  = $pfecha3->output;
		$data["prepro3"]  = $prepro3->output;
		$data["formcal"]  = $formcal->output;
		$data["redecen"]  = $redecen->output;
		$data["dpto"]     = $dpto->output;
		$data["linea"]    = $linea->output;
		$data["frupo"]    = $grupo->output;
		$data["garantia"] = $garantia->output;
		
		$data["alma"]     = $do->get_related("alma");
		$data["control"]  = $save->output;
		$data["form"]     = "";
		$data["form"]     = form_open("inventario/maestro/dataedit/modify/$consul");
		
		$data["modulo"] = "";
		
		$content["content"] = $this->load->view('view_sinvmaestro', $data, true);
		$content["rapyd_head"] = $script.$this->rapyd->get_head().script('control.tabs.js');
		$content["code"]  = "";
		$content["lista"] = "
			<h3>Editar o Agregar</h3>
			<div></div>
			<div class='line'></div>
			<a href='#' onclick='window.close()'>Cerrar</a>
			<div class='line'></div>\n<br><br><br>\n";
		
		$this->load->view('rapyd/tmpsolo', $content);
	}
}
?>